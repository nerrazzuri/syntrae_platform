"""AI Core package."""
