from ai_core.capabilities.score.score_capability import ScoreCapability
