from .recommend_capability import RecommendCapability
